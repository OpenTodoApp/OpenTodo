# Plan the garden

Assignee: Sam Example
Due: October 29, 2026
Priority: High 🔥
Status: In progress
Tags: Home, Outdoor

Tulips along the fence, herbs by the door.

Ask the neighbours about the hedge first.

- [ ]  Buy bulbs
- [x]  Measure the beds

![Sketch](Plan%20the%20garden/sketch.png)