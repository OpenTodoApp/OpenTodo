# Write the newsletter

Assignee: Sam Example, Alex Example
Due: November 10, 2026 3:00 PM
Priority: Low
Status: Not started

Topics: the move, the garden.